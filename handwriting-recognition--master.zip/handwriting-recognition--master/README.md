# handwriting-recognition-
Recognizing the single digits with the help of sklearn and pylab 
